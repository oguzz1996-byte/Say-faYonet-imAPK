# Sayfa Yönetim Android

Sıfırdan oluşturulmuş Kotlin + Jetpack Compose başlangıç projesi.

## Mevcut durum

Bu teslimat, ilk arayüz prototipidir. Sohbet ekranı, araç kartları, menü ve temel gezinme arayüzü içerir.

**Henüz tamamlanmayanlar:** kalıcı sohbet veritabanı, Gemini API, gerçek dosya/kamera/ses entegrasyonu, kaynaklı web araştırması, görsel üretimi, Meta OAuth, sunucu taraflı planlı yayın, yedekleme ve otomatik test kapsamı.

Uygulama AI bağlantısı varmış gibi davranmaz; mesaj gönderildiğinde ekranda geliştirme aşamasını belirten bir açıklama gösterir.

## Gereksinimler

- Android Studio güncel kararlı sürüm
- JDK 17
- Android SDK Platform 36
- İnternet bağlantısı (Gradle bağımlılıklarını indirmek için)

## Android Studio ile açma

1. ZIP dosyasını bir klasöre çıkar.
2. Android Studio'da `SayfaYonetimAndroid` klasörünü aç.
3. Gradle senkronizasyonunun tamamlanmasını bekle.
4. Android 8.0 (API 26) veya üzeri cihaz/emülatör seç.
5. Run ile çalıştır.

## Windows üzerinden APK

Android SDK ve JDK 17 kuruluysa proje klasöründe:

```bat
gradlew.bat assembleDebug
```

Çıktı:
`app\build\outputs\apk\debug\app-debug.apk`

Bu ZIP içinde Gradle Wrapper JAR dosyası yer almamaktadır; Android Studio wrapper üretmezse yerel Gradle kurulumuyla `gradle wrapper` çalıştırılması veya Android Studio üzerinden derleme yapılması gerekir.

## Sonraki geliştirme aşamaları

1. Room ile sohbet ve taslakların kalıcı kaydı.
2. Gemini API'ye güvenli sunucu üzerinden erişim.
3. Dosya seçici, kamera ve sesli giriş.
4. Haber araştırma ve kaynak gösterimi.
5. Görsel üretimi ve onaylı Perseid anket şablonu.
6. Meta OAuth ve izinli gönderi yayımlama.
7. Sunucu tabanlı planlı yayın, durum takibi ve tekrar deneme.
8. Otomatik testler, erişilebilirlik ve yedekleme.

package com.oguzlar.sayfayonetim

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Message
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BrandBlue = Color(0xFF2457D6)
private val SoftBackground = Color(0xFFF5F7FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SayfaYonetimApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SayfaYonetimApp() {
    var prompt by remember { mutableStateOf("") }
    var selectedTool by remember { mutableStateOf<String?>(null) }
    var showMenu by remember { mutableStateOf(false) }
    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage("Merhaba! Ben Sayfa Yönetim asistanınım. Haber araştırabilir, anket ve görsel hazırlayabilir veya gelen mesajlara yanıt oluşturabiliriz. Ne yapmak istersin?", false)
            )
        )
    }
    var status by remember { mutableStateOf("Yerel taslak modu hazır") }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = BrandBlue,
            background = SoftBackground,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = SoftBackground,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Sayfa Yönetim", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text("Bigadiç Anket Haber", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menü")
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            messages = emptyList()
                            selectedTool = null
                            status = "Yeni sohbet"
                        }) { Icon(Icons.Default.Add, contentDescription = "Yeni sohbet") }
                    }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        selected = selectedTool == null,
                        onClick = { selectedTool = null },
                        icon = { Icon(Icons.Default.ChatBubbleOutline, null) },
                        label = { Text("Sohbet") }
                    )
                    NavigationBarItem(
                        selected = selectedTool == "Arşiv",
                        onClick = { selectedTool = "Arşiv" },
                        icon = { Icon(Icons.Default.Archive, null) },
                        label = { Text("Arşiv") }
                    )
                    NavigationBarItem(
                        selected = selectedTool == "Takvim",
                        onClick = { selectedTool = "Takvim" },
                        icon = { Icon(Icons.Default.CalendarMonth, null) },
                        label = { Text("Yayın") }
                    )
                    NavigationBarItem(
                        selected = selectedTool == "Ayarlar",
                        onClick = { selectedTool = "Ayarlar" },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Ayarlar") }
                    )
                }
            }
        ) { padding ->
            if (selectedTool == "Arşiv" || selectedTool == "Takvim" || selectedTool == "Ayarlar") {
                UtilityScreen(selectedTool!!, Modifier.padding(padding))
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (messages.size <= 1) {
                        Spacer(Modifier.height(8.dp))
                        Text("Bugün ne hazırlayalım?", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("İsteğini yazabilir, bir araç seçebilir veya görsel ekleyebilirsin.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        ToolGrid(onSelect = {
                            selectedTool = it
                            prompt = when (it) {
                                "Haber araştır" -> "Bigadiç için güncel haberleri resmî kaynaklardan araştır."
                                "Görsel oluştur" -> "Instagram için bir görsel hazırla."
                                "Anket hazırla" -> "Bigadiç için iki seçenekli bir Instagram anketi öner."
                                "Mesaj yanıtla" -> "Bu mesaj için uygun bir yanıt hazırla."
                                "Video promptu" -> "Bir video üretim promptu hazırla."
                                else -> ""
                            }
                        })
                    }
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        items(messages) { msg ->
                            MessageBubble(msg)
                        }
                    }
                    Text(status, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Surface(shape = RoundedCornerShape(24.dp), color = Color.White, shadowElevation = 2.dp) {
                        Column(Modifier.padding(10.dp)) {
                            OutlinedTextField(
                                value = prompt,
                                onValueChange = { prompt = it },
                                placeholder = { Text("Mesajını yaz…") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 1,
                                maxLines = 5,
                                shape = RoundedCornerShape(18.dp)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row {
                                    IconButton(onClick = { status = "Dosya ekleme sonraki aşamada bağlanacak." }) {
                                        Icon(Icons.Default.AttachFile, "Dosya ekle")
                                    }
                                    IconButton(onClick = { status = "Kamera entegrasyonu sonraki aşamada bağlanacak." }) {
                                        Icon(Icons.Default.CameraAlt, "Kamera")
                                    }
                                    IconButton(onClick = { status = "Sesli giriş sonraki aşamada bağlanacak." }) {
                                        Icon(Icons.Default.Mic, "Sesli giriş")
                                    }
                                }
                                Button(
                                    onClick = {
                                        val text = prompt.trim()
                                        if (text.isNotEmpty()) {
                                            messages = messages + ChatMessage(text, true) +
                                                ChatMessage(
                                                    "Bu başlangıç sürümünde sohbet arayüzü hazır. Çevrim içi Gemini bağlantısı henüz yapılandırılmadı; bu mesaj kaydedilmeden yalnızca ekranda tutuluyor. Sonraki geliştirme aşamasında AI servisi ve yerel kayıt eklenecek.",
                                                    false
                                                )
                                            prompt = ""
                                            status = "AI bağlantısı yapılandırılmayı bekliyor"
                                        }
                                    },
                                    enabled = prompt.isNotBlank(),
                                    shape = CircleShape,
                                    contentPadding = PaddingValues(12.dp)
                                ) { Icon(Icons.Default.Send, "Gönder") }
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
        }

        if (showMenu) {
            ModalNavigationDrawer(
                drawerContent = {
                    ModalDrawerSheet {
                        Text("Araçlar", modifier = Modifier.padding(20.dp), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        val tools = listOf("Haber araştır", "Haber hazırla", "Görsel oluştur", "Anket hazırla", "Video promptu", "Mesaj yanıtla", "İlan hazırla", "Yayın kontrolü")
                        tools.forEach { tool ->
                            NavigationDrawerItem(
                                label = { Text(tool) },
                                selected = false,
                                onClick = {
                                    selectedTool = tool
                                    showMenu = false
                                    status = "$tool seçildi"
                                },
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )
                        }
                    }
                },
                gesturesEnabled = true
            ) { }
        }
    }
}

@Composable
private fun ToolGrid(onSelect: (String) -> Unit) {
    val items = listOf(
        Triple("Haber araştır", "Kaynaklı güncel haberler", Icons.Default.Newspaper),
        Triple("Görsel oluştur", "Gönderi, Story ve ilan", Icons.Default.Image),
        Triple("Anket hazırla", "Soru ve iki seçenek", Icons.Default.Poll),
        Triple("Mesaj yanıtla", "Yorum ve ekran görüntüsü", Icons.Default.Message)
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowItems.forEach { item ->
                    Card(
                        modifier = Modifier.weight(1f).clickable { onSelect(item.first) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(item.third, contentDescription = null, tint = BrandBlue, modifier = Modifier.size(26.dp))
                            Text(item.first, fontWeight = FontWeight.SemiBold)
                            Text(item.second, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (message.fromUser) BrandBlue else Color.White,
            shadowElevation = 1.dp,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Text(
                message.text,
                modifier = Modifier.padding(14.dp),
                color = if (message.fromUser) Color.White else Color(0xFF202124),
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun UtilityScreen(title: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        when (title) {
            "Arşiv" -> Text("Kaydedilen sohbetler ve içerikler için yerel veritabanı bir sonraki aşamada eklenecek.")
            "Takvim" -> Text("Planlanan yayın görevleri ve Meta sunucu bağlantısı sonraki aşamada eklenecek.")
            else -> Text("AI sağlayıcısı, tema, güvenlik ve bağlantı ayarları sonraki aşamada eklenecek.")
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Text(
                "Proje başlangıç sürümü: bu ekrandaki bilgiler henüz kalıcı veritabanına kaydedilmiyor.",
                modifier = Modifier.padding(16.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

# Özellik Durumu — v0.1.0

| Özellik | Durum |
|---|---|
| Compose ana ekranı | Kodlandı, derleme henüz doğrulanmadı |
| Sohbet balonları | Kodlandı; kalıcı kayıt yok |
| Araç kartları ve menüsü | Kodlandı |
| Alt gezinme | Kodlandı |
| Yerel Room veritabanı | Henüz geliştirilmedi |
| Gemini bağlantısı | Henüz geliştirilmedi |
| Web araştırması ve kaynaklar | Henüz geliştirilmedi |
| Görsel üretimi | Henüz geliştirilmedi |
| Dosya/kamera/ses | Arayüz yer tutucuları |
| Meta OAuth | Henüz geliştirilmedi |
| Anında/planlı yayın | Henüz geliştirilmedi |
| Yedekleme ve geri yükleme | Henüz geliştirilmedi |
| Otomatik testler | Henüz geliştirilmedi |
